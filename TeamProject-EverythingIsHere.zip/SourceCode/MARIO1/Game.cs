﻿using System;

    class Game
    {
        static void Main()
        {
            //Engine.Run();
            //Console.BackgroundColor = ConsoleColor.Black;
            //Console.Clear();
            Console.Title = "Super Shapkario";
            Menu.Display();

        }
    }

